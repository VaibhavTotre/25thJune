package basicpackage;

public class basicsofjava {

public static void main(String[] args)	{
//types of print statements
System.out.println("200+200"); //message
System.out.println(200+200); //numeric
System.out.print("Vaibhav"); //no space
System.out.println("Vaibhav");
//leaves 1 line
System.out.println("Vaibhav "   +100);
System.out.println("hi");
System.out.println("Hello");
System.out.println("     Hello");
System.out.println("          Hello");
}
}