package collectionsInJava;

import java.util.LinkedList;
import java.util.Vector;

public class Collections3 
{
 public static void main(String[] args) {
	
	 LinkedList x = new LinkedList();
	 
	 Vector v = new Vector();
}
}
