package methodOverriding;

public class StaticMethodOverriding {

	public static void Rahul()
	{
		System.out.println("Super");
	}
}
