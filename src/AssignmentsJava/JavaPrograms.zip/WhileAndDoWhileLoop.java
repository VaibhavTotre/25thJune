package AssignmentsJava;

public class WhileAndDoWhileLoop {
public static void main(String[] args) {
	
	//1)while loop eg.1)WTP to print no. from 1 to 5
	int i=1;
	while(i<=5)
	{System.out.println(i);
	i++;
}
	System.out.println();
 //do while loop eg 1)Write the numbers from 1 to 10
	int a=1;
	do
	{System.out.println(a);
    a++;
	}
	while (a<=10);
}
}








