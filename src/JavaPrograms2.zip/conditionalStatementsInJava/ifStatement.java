package conditionalStatementsInJava;

public class ifStatement {
	
	public static void main(String[]args) {
int passingMarks=35;
int studentMarks=34;
if(studentMarks>=passingMarks)
{System.out.println("Student is passed");}
	
	
	
	
	}
	
	}
