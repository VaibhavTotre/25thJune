package conditionalStatementsInJava;


public class EvenandOdd {
public static void main(String[] args) {
	int a=87;
	if(a%2!=0)
	{System.out.println("a is odd");}
	else
		
	{System.out.println("a is even");}
//int b=25;
//System.out.println(b%2);
//int c=13;
//int d=c%2;
}}


