package conditionalStatementsInJava;

public class AssignmentProgram {
public static void main(String[] args) {
//	
	int i=1;
for(i=2;i<=20;i=i+2)
	
	{System.out.println(i);
}
}

}
