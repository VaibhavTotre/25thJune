package abstraction;

public interface Interface1 
{
 int a=18;
 void method1();
 void method2();
 public static void main(String[] args) 
 {
	
}
 
}
