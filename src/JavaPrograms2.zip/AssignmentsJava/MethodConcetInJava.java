package AssignmentsJava;

public class MethodConcetInJava {

	public static void vaibhavIntroduction()
	{
		System.out.println("Vaibhav B. Totre");
		System.out.println("Email Id : vaibhavtotre123@gmail.com");
		System.out.println("DOB : 03rd May 2000");
		System.out.println("Mobile Number : 9766330238");
		System.out.println("Blood Group : A+ve");
	}
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
//		vaibhavIntroduction();
//		System.out.println(123);
//		vaibhavIntroduction();
//        System.out.println(456);
//        vaibhavIntroduction();
//        System.out.println(789);
//	
	}
}
