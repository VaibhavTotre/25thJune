package basicpackage;

public class OperatorsinJava {
public static void main(String[] args) {

	int a= 10;
	int b =21;
	double c = b/a;
	System.out.println(c);
}
}