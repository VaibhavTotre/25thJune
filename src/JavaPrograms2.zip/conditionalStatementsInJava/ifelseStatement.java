package conditionalStatementsInJava;

public class ifelseStatement {
public static void main(String[]args) {
	int passingMarks=35;
	int student1Marks=65;
	if(student1Marks>=passingMarks)
	{System.out.println("Student1 is passed");
	}
	else
	{System.out.println("Student1 is fail");
	}
	
	int student2Marks=34;
	if(student2Marks>=passingMarks)
	{System.out.println("Student2 is passed");
	}
	else
	{System.out.println("Student2 is fail");
	}
	
//To find greater number between two numbers
	int a= 19;
	int b= 18;
	if(a>b)
	{System.out.println("a is greater than b");
	}
	else
	{System.out.println("b is greater than a");
	}
	
	}
	}
	





		


