package conditionalStatementsInJava;

public class LoopingStatements {
public static void main(String[] args) {
	//wtp to compile vaibhav message 20 times
	//we use for statement for this
	int i;
	for (i=1;i<=20;i++)
	{System.out.println("Vaibhav");
	
	}
}
}
