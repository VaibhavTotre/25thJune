package methodOverriding;

public class StaticMethodOverriding2 extends StaticMethodOverriding
{
public static void Rahul()
{
	System.out.println("sub");
}
public static void main(String[] args) 
{
	Rahul();
}
}
